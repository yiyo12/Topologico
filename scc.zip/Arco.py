#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 13:45:23 2020

@author: lbeltran
"""


class Arco:
    def __init__(self,origen, destino, costo):
        self.origen=origen
        self.destino=destino
        self.costo=costo
        
        